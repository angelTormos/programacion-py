temperaturaF = float(input("Introduce una temperatura en ºF "))
temperaturaC = (temperaturaF-32)*5/9

print(temperaturaF, "ºFahrenheit, son", temperaturaC, "ºCelsius")