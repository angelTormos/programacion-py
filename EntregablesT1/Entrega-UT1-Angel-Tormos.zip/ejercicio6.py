num1 = float(input("Introduce el prmier numero "))
num2 = float(input("Introduce el segundo numero "))
num3 = float(input("Introduce el tercer numero "))

media = (num1 + num2 + num3) / 3

print("La media de", num1, num2, num3, "es igual a", media)