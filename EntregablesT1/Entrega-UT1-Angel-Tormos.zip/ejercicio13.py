import math

num = float(input('Introduce un valor '))

num_cuadrado = math.sqrt(num)
num_cubico = math.cbrt(num)

print('Cuadrado:', num_cuadrado, '\nCubico', num_cubico)