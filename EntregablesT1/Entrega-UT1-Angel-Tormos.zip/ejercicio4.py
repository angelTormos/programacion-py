num1 = float(input("Introduce el primer nuemero"))
num2 = float(input("Introduce el segundo nuemero"))

suma = num1 + num2
resta = num1 - num2
multiplicacion = num1 * num2
division = num1 / num2

print(num1, "+", num2, "=", suma, "\n", num1, "-", num2, "=", resta, "\n", num1, "*", num2, "=", multiplicacion, "\n", num1, "/", num2, "=", division)