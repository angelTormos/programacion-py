num1 = float(input('Introduce el primer numero '))
num2 = float(input('Introduce el segundo numero '))

distancia = abs(num1 - num2)

print('La distancia es de', distancia)