base = float(input("Introduce la base del rectangulo "))
altura = float(input("Introduce la altura del rectangulo "))

area = base * altura
perimetro = (2*base) + (2*altura)

print("El perimetro es de", perimetro , "\nEl area es de", area)