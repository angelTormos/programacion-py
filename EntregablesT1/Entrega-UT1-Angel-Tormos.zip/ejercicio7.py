minutos = int(input("Introduce un valor en minutos "))

horas = minutos // 60
resto_min = minutos % 60

print(horas, "horas", resto_min, "minutos")