precio_total = float(input('Introduce el importe total de la compra: '))
precio_descuento = precio_total - (precio_total * 0.15)

print('El precio con descuento será de ', precio_descuento, '€')
