nombre = input("Nombre: ")
apellido1 = input("Primer apellido: ")
apellido2 = input("Segundo apellido: ")

iniciales = nombre[0].upper() + apellido1[0].upper() + apellido2[0].upper()

print("Las iniciales son: ",iniciales)
