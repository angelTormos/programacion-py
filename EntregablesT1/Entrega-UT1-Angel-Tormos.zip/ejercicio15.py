a = int(input('Introduce el primer valor '))
b = int(input('Introduce el segundo valor '))
ab = 0

ab = a
a = b
b = ab

print(a, b)