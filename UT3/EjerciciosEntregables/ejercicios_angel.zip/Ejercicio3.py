hostnames = input("Introduce un hostname ")
contador = 0

while hostnames != "FIN":
    hostnames = input("Introduce otro hostname ")
    contador += 1

print(contador)