import modulo_angel

# Ejercicio 1

print(modulo_angel.mayor(7, 5))

# Ejercicio 3

print(modulo_angel.es_par(55))

# Ejercicio 6
    
print(modulo_angel.es_mayusculas('hrthrthtrht'))

# Ejercicio 7
    
print(modulo_angel.potencia(44, 5))

# Ejercicio 9

print(modulo_angel.ordena_mayor_menor(48, 2, 150))

# Ejercicio 10

modulo_angel.clasifica_circunferencias(123, 32, 4, 543, 564, 87)

# Ejercicio 11

modulo_angel.clasifica_triangulo(32, 54, 32)

# Ejercicio 12

print(modulo_angel.es_bisiesto(2029))

# Ejercicio 13

print(modulo_angel.es_fecha_correcta(30, 11, 2028))

# Ejercicio 14

print(modulo_angel.calcula_ganancias_uva(12, 150, "A", 1))

# Ejercicio 15

print(modulo_angel.costes_viaje(67))

# Ejercicio 16

print(modulo_angel.coste_llamada(120, "N", "M"))

# Ejercicio 18
    
print(modulo_angel.dia_escrito(7))

# Ejercicio 19

print(modulo_angel.num_dias_mes(12))

# Ejercicio 20

print(modulo_angel.calcula_coste_transporte(254, 4))

# Ejercicios para practicar bucles

# Ejercicio 1

print(modulo_angel.factorial(6))

# Ejercicio 5

modulo_angel.pares_entre(2, 9)

# Ejercicio 6

modulo_angel.tabla_multiplicar(4)

# Ejercicio 10

modulo_angel.adivina_numero(6)

# Ejercicio 11

print(modulo_angel.es_primo(6))

# Ejercicio 20

modulo_angel.primeros_primos(15)